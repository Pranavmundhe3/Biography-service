package com.info.biographyservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BiographyServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
