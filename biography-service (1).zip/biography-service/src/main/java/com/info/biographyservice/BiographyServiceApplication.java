package com.info.biographyservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BiographyServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BiographyServiceApplication.class, args);
	}

}
